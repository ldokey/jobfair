package kr.happyjob.study.system.model;

public class NoticeModel {
	
	// 게시판 글 번호
	private int notice_no;
	private int row_num;
	private String loginID;
	private String noticeTitle;
	private String noticeContent;
	private String noticeRegdate;
	private String from_date;
	private String to_date;
	
	
	
	
}
