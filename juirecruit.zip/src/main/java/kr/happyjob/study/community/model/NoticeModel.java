package kr.happyjob.study.community.model;

public class NoticeModel {

	private int notice_no;
	private String loginID;
	private int file_cd;
	private int is_delete;
	private String update_date;
	private String reg_date;
	private String notice_content;
	private String notice_title;
	private int notice_count;
	private String writer;
	private String file_name;
	private String file_nadd;
	private String file_madd;
	private int file_size;

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getFile_nadd() {
		return file_nadd;
	}

	public void setFile_nadd(String file_nadd) {
		this.file_nadd = file_nadd;
	}

	public String getFile_madd() {
		return file_madd;
	}

	public void setFile_madd(String file_madd) {
		this.file_madd = file_madd;
	}

	public int getFile_size() {
		return file_size;
	}

	public void setFile_size(int file_size) {
		this.file_size = file_size;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getNotice_no() {
		return notice_no;
	}

	public void setNotice_no(int notice_no) {
		this.notice_no = notice_no;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

	public int getFile_cd() {
		return file_cd;
	}

	public void setFile_cd(int file_cd) {
		this.file_cd = file_cd;
	}

	public int getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(int is_delete) {
		this.is_delete = is_delete;
	}

	public String getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

	public String getNotice_content() {
		return notice_content;
	}

	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}

	public String getNotice_title() {
		return notice_title;
	}

	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}

	public int getNotice_count() {
		return notice_count;
	}

	public void setNotice_count(int notice_count) {
		this.notice_count = notice_count;
	}

}
