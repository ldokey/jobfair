package kr.happyjob.study.dashboard.model;



public class MonthProductVO {

	private String pro_no;
	private String pro_name;
	private int profit_price;
	public String getPro_no() {
		return pro_no;
	}
	public void setPro_no(String pro_no) {
		this.pro_no = pro_no;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public int getProfit_price() {
		return profit_price;
	}
	public void setProfit_price(int profit_price) {
		this.profit_price = profit_price;
	}
	
}
