package kr.happyjob.study.dashboard.model;

public class FileModel {
	
	private int file_no;	
	private String file_server_path;	
	private String file_local_path;	
	private String file_new_name;
	private String file_ofname;
	private int file_size;	
	private String notice_no;
	private String pro_no;
	private String file_exts; //파일 확장자(DB에는 없음)
	
	public int getFile_no() {
		return file_no;
	}
	public void setFile_no(int file_no) {
		this.file_no = file_no;
	}
	public String getFile_server_path() {
		return file_server_path;
	}
	public void setFile_server_path(String file_server_path) {
		this.file_server_path = file_server_path;
	}
	public String getFile_local_path() {
		return file_local_path;
	}
	public void setFile_local_path(String file_local_path) {
		this.file_local_path = file_local_path;
	}
	public String getFile_new_name() {
		return file_new_name;
	}
	public void setFile_new_name(String file_new_name) {
		this.file_new_name = file_new_name;
	}
	public String getFile_ofname() {
		return file_ofname;
	}
	public void setFile_ofname(String file_ofname) {
		this.file_ofname = file_ofname;
	}
	public int getFile_size() {
		return file_size;
	}
	public void setFile_size(int file_size) {
		this.file_size = file_size;
	}
	public String getNotice_no() {
		return notice_no;
	}
	public void setNotice_no(String notice_no) {
		this.notice_no = notice_no;
	}
	public String getPro_no() {
		return pro_no;
	}
	public void setPro_no(String pro_no) {
		this.pro_no = pro_no;
	}
	public String getFile_exts() {
		return file_exts;
	}
	public void setFile_exts(String file_exts) {
		this.file_exts = file_exts;
	}

}
