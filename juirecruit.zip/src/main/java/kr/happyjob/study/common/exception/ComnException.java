package kr.happyjob.study.common.exception;

public class ComnException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2098793692912582764L;

	public ComnException() {
		
	}
	
	public ComnException(String msg) {
		super(msg);
	}
}
